function generateMaze(width, height) {
    try {
        // Initialize maze with walls
        const maze = Array(height).fill().map(() => Array(width).fill(1));
        
        function carve(x, y) {
            maze[y][x] = 0;
            
            const directions = [
                [0, -2], // Up
                [2, 0],  // Right
                [0, 2],  // Down
                [-2, 0]  // Left
            ];
            
            // Shuffle directions
            for (let i = directions.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [directions[i], directions[j]] = [directions[j], directions[i]];
            }
            
            // Try each direction
            for (const [dx, dy] of directions) {
                const newX = x + dx;
                const newY = y + dy;
                
                if (newX > 0 && newX < width - 1 && newY > 0 && newY < height - 1 && maze[newY][newX] === 1) {
                    maze[y + dy/2][x + dx/2] = 0;
                    carve(newX, newY);
                }
            }
        }
        
        // Start from a random point
        carve(1, 1);
        
        return maze;
    } catch (error) {
        reportError(error);
        return Array(height).fill().map(() => Array(width).fill(1));
    }
}
