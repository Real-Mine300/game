function handlePlayerMovement(direction, playerPosition, maze) {
    try {
        const newPosition = { ...playerPosition };
        
        switch(direction) {
            case 'up':
                if (maze[playerPosition.z - 1]?.[playerPosition.x] === 0) {
                    newPosition.z -= 1;
                }
                break;
            case 'down':
                if (maze[playerPosition.z + 1]?.[playerPosition.x] === 0) {
                    newPosition.z += 1;
                }
                break;
            case 'left':
                if (maze[playerPosition.z]?.[playerPosition.x - 1] === 0) {
                    newPosition.x -= 1;
                }
                break;
            case 'right':
                if (maze[playerPosition.z]?.[playerPosition.x + 1] === 0) {
                    newPosition.x += 1;
                }
                break;
        }
        
        return newPosition;
    } catch (error) {
        reportError(error);
        return playerPosition;
    }
}
