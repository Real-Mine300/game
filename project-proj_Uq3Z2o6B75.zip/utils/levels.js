const levels = [
    {
        id: 1,
        size: [10, 10],
        difficulty: 'easy',
        timeLimit: 120
    },
    {
        id: 2,
        size: [12, 12],
        difficulty: 'easy',
        timeLimit: 180
    },
    {
        id: 3,
        size: [15, 15],
        difficulty: 'medium',
        timeLimit: 240
    },
    {
        id: 4,
        size: [18, 18],
        difficulty: 'medium',
        timeLimit: 300
    },
    {
        id: 5,
        size: [20, 20],
        difficulty: 'hard',
        timeLimit: 360
    },
    {
        id: 6,
        size: [25, 25],
        difficulty: 'hard',
        timeLimit: 420
    },
    {
        id: 7,
        size: [30, 30],
        difficulty: 'expert',
        timeLimit: 480
    }
];

function getLevelConfig(levelId) {
    try {
        return levels.find(level => level.id === levelId) || levels[0];
    } catch (error) {
        reportError(error);
        return levels[0];
    }
}
