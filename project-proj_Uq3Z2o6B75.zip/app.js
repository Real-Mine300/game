function App() {
    const [maze, setMaze] = React.useState([]);
    const [playerPosition, setPlayerPosition] = React.useState({ x: 1, z: 1 });
    const [exitPosition, setExitPosition] = React.useState({ x: 0, z: 0 });
    const [rotation, setRotation] = React.useState(0);
    const [currentLevel, setCurrentLevel] = React.useState(1);
    const [isDay, setIsDay] = React.useState(true);
    const [gameStarted, setGameStarted] = React.useState(false);

    React.useEffect(() => {
        try {
            const level = getLevelConfig(currentLevel);
            const generatedMaze = generateMaze(...level.size);
            setMaze(generatedMaze);
            
            const exitX = generatedMaze[0].length - 2;
            const exitZ = generatedMaze.length - 2;
            setExitPosition({ x: exitX, z: exitZ });
            
            generatedMaze[exitZ][exitX] = 0;

            // Set up day/night cycle
            const dayDuration = 420000; // 7 minutes
            const nightDuration = 300000; // 5 minutes
            const cycleInterval = setInterval(() => {
                setIsDay(prev => !prev);
            }, isDay ? dayDuration : nightDuration);

            return () => clearInterval(cycleInterval);
        } catch (error) {
            reportError(error);
        }
    }, [currentLevel]);

    React.useEffect(() => {
        try {
            const handleKeyPress = (e) => {
                // Movement controls (WASD) - Note: W and S are swapped
                switch(e.key.toLowerCase()) {
                    case 'w':
                        handleMove('down');
                        break;
                    case 's':
                        handleMove('up');
                        break;
                    case 'a':
                        handleMove('left');
                        break;
                    case 'd':
                        handleMove('right');
                        break;
                }

                // Camera controls (Arrow keys) - 15 degree rotation
                switch(e.key) {
                    case 'ArrowLeft':
                        setRotation(prev => prev + 15);
                        break;
                    case 'ArrowRight':
                        setRotation(prev => prev - 15);
                        break;
                }
            };

            window.addEventListener('keydown', handleKeyPress);
            return () => window.removeEventListener('keydown', handleKeyPress);
        } catch (error) {
            reportError(error);
        }
    }, [maze, playerPosition]);

    const handleMove = (direction) => {
        try {
            const newPosition = handlePlayerMovement(direction, playerPosition, maze);
            setPlayerPosition(newPosition);
            
            if (newPosition.x === exitPosition.x && newPosition.z === exitPosition.z) {
                alert(`Level ${currentLevel} completed!`);
                if (currentLevel < levels.length) {
                    setCurrentLevel(currentLevel + 1);
                    setPlayerPosition({ x: 1, z: 1 });
                    setRotation(0);
                    setGameStarted(false);
                } else {
                    alert('Congratulations! You completed all levels!');
                    window.location.reload();
                }
            }
        } catch (error) {
            reportError(error);
        }
    };

    const handleLevelSelect = (level) => {
        setCurrentLevel(level);
        setPlayerPosition({ x: 1, z: 1 });
        setRotation(0);
        setGameStarted(true);
    };

    return (
        <div data-name="game-wrapper">
            <Environment isDay={isDay} />
            {!gameStarted && (
                <LevelSelect currentLevel={currentLevel} onLevelSelect={handleLevelSelect} />
            )}
            <Maze3D 
                maze={maze}
                playerPosition={playerPosition}
                exitPosition={exitPosition}
                rotation={rotation}
            />
            <Controls onMove={handleMove} />
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
