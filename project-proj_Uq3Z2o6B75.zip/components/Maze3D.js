function Maze3D({ maze, playerPosition, exitPosition, rotation }) {
    const CELL_SIZE = 50;
    const WALL_HEIGHT = 100;

    function renderWalls() {
        const walls = [];
        
        try {
            for (let i = 0; i < maze.length; i++) {
                for (let j = 0; j < maze[0].length; j++) {
                    if (maze[i][j] === 1) {
                        const x = j * CELL_SIZE;
                        const z = i * CELL_SIZE;
                        
                        // Create all four walls for each cell to eliminate gaps
                        walls.push(
                            <div
                                key={`wall-${i}-${j}-front`}
                                data-name="maze-wall-front"
                                className="wall"
                                style={{
                                    width: CELL_SIZE + 'px',
                                    height: WALL_HEIGHT + 'px',
                                    transform: `translate3d(${x}px, ${-WALL_HEIGHT/2}px, ${z}px)`,
                                }}
                            />,
                            <div
                                key={`wall-${i}-${j}-back`}
                                data-name="maze-wall-back"
                                className="wall"
                                style={{
                                    width: CELL_SIZE + 'px',
                                    height: WALL_HEIGHT + 'px',
                                    transform: `translate3d(${x}px, ${-WALL_HEIGHT/2}px, ${z + CELL_SIZE}px)`,
                                }}
                            />,
                            <div
                                key={`wall-${i}-${j}-left`}
                                data-name="maze-wall-left"
                                className="wall"
                                style={{
                                    width: CELL_SIZE + 'px',
                                    height: WALL_HEIGHT + 'px',
                                    transform: `translate3d(${x}px, ${-WALL_HEIGHT/2}px, ${z}px) rotateY(90deg)`,
                                }}
                            />,
                            <div
                                key={`wall-${i}-${j}-right`}
                                data-name="maze-wall-right"
                                className="wall"
                                style={{
                                    width: CELL_SIZE + 'px',
                                    height: WALL_HEIGHT + 'px',
                                    transform: `translate3d(${x + CELL_SIZE}px, ${-WALL_HEIGHT/2}px, ${z}px) rotateY(90deg)`,
                                }}
                            />
                        );
                    }
                }
            }
            return walls;
        } catch (error) {
            reportError(error);
            return [];
        }
    }

    const cameraX = -playerPosition.x * CELL_SIZE;
    const cameraZ = -playerPosition.z * CELL_SIZE;
    const mazeWidth = maze[0]?.length * CELL_SIZE || 0;
    const mazeDepth = maze.length * CELL_SIZE || 0;

    return (
        <div data-name="maze-container" className="game-container">
            <div 
                data-name="maze"
                className="maze"
                style={{
                    transform: `translate3d(${window.innerWidth/2 + cameraX}px, ${window.innerHeight/2}px, ${400 + cameraZ}px) 
                               rotateX(60deg) rotateY(${rotation}deg)`
                }}
            >
                <div 
                    data-name="floor" 
                    className="floor" 
                    style={{
                        width: `${mazeWidth}px`,
                        height: `${mazeDepth}px`
                    }}
                />
                {renderWalls()}
                <div
                    data-name="player"
                    className="player"
                    style={{
                        transform: `translate3d(${playerPosition.x * CELL_SIZE}px, ${-10}px, ${playerPosition.z * CELL_SIZE}px)`
                    }}
                />
                <div
                    data-name="exit"
                    className="exit"
                    style={{
                        transform: `translate3d(${exitPosition.x * CELL_SIZE}px, ${-10}px, ${exitPosition.z * CELL_SIZE}px)`
                    }}
                />
            </div>
        </div>
    );
}
