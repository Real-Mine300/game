function Controls({ onMove }) {
    return (
        <div data-name="controls" className="controls">
            <button 
                data-name="up-button"
                className="control-btn"
                onClick={() => onMove('up')}
            >
                W
            </button>
            <button 
                data-name="left-button"
                className="control-btn"
                onClick={() => onMove('left')}
            >
                A
            </button>
            <button 
                data-name="down-button"
                className="control-btn"
                onClick={() => onMove('down')}
            >
                S
            </button>
            <button 
                data-name="right-button"
                className="control-btn"
                onClick={() => onMove('right')}
            >
                D
            </button>
        </div>
    );
}
