function Environment({ isDay }) {
    return (
        <div data-name="environment" className="environment">
            <div className={`sky ${isDay ? 'day' : 'night'}`}>
                {isDay ? (
                    <div 
                        data-name="sun"
                        className="sun"
                        style={{
                            transform: `translate(${50 + Math.sin(Date.now() / 1000) * 40}vw, ${50 + Math.cos(Date.now() / 1000) * 40}vh)`
                        }}
                    />
                ) : (
                    <div 
                        data-name="moon"
                        className="moon"
                        style={{
                            transform: `translate(${50 + Math.sin(Date.now() / 1000) * 40}vw, ${50 + Math.cos(Date.now() / 1000) * 40}vh)`
                        }}
                    />
                )}
            </div>
            <div data-name="ground" className="ground" />
        </div>
    );
}
