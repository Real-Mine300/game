function LevelSelect({ currentLevel, onLevelSelect }) {
    return (
        <div data-name="level-select" className="level-select">
            <h2 className="text-2xl mb-4 text-white">Select Level</h2>
            <div className="grid grid-cols-4 gap-4">
                {levels.map(level => (
                    <button
                        key={level.id}
                        data-name={`level-${level.id}-button`}
                        className={`level-btn ${currentLevel === level.id ? 'active' : ''}`}
                        onClick={() => onLevelSelect(level.id)}
                    >
                        Level {level.id}
                    </button>
                ))}
            </div>
        </div>
    );
}
